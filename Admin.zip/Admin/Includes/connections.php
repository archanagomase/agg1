<?php
$servername="localhost";
$localhost="root";
$password="";
$db_name="intcap";
$conn=mysqli_connect($servername,$localhost,$password,$db_name);



?>