<style>
	
   .right span {
			
		}
    
</style>
<?php

error_reporting(0);
           $Username=$_SESSION['AdminUsername'];
           include 'Includes/connections.php';
           $query="select date from admin where username='$Username'";
     
           $success = mysqli_query($conn, $query);
                    if(mysqli_num_rows($success)>0) {
                    while($row=mysqli_fetch_assoc($success))
                       {
					    $date=$row['date'];
						}
						}
?>

<div id="header">
		<div id="top">
			<div class="left">
				  <span class="logo">
           <img src="img/appreazlogo2.jpg" alt="" style=" position:absolute;         
          ">
       </span> 
			</div>
			<div class="right">
			<span class="lite">Welcome <?php echo $Username;?></span>
				 </span> <span class="lite"><?php echo $date;?></span>
			</div>
		</div>

	</div>