<div id="footer">
		<div class="left">
			<p>Designed & Developed by <a href="http://www.appmonks.net/">Appmonks</a></p>
		</div>

	</div>