<div id="sidebar">

			 <div class="box">
				<div class="h_title">&#8250; Dashboard</div>
				<?php 
				if($page=="details"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="details.php">Details</a></li>										
										
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Jobs</div>
				<?php 
				if($page=="Jobs"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="jobs.php">Jobs</a></li>								
						
				</ul>
			</div>
            <div class="box">
				<div class="h_title">&#8250; Applications</div>
				<?php 
				if($page=="application"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="applications.php">Applications</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Recuiters</div>
				<?php 
				if($page=="Recruiter"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="Recruiter.php">Recuiters</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Create Backup</div>
				<?php 
				if($page=="backup"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="backup.php">Create Backup</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Users</div>
				<?php 
				if($page=="users"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="users.php">Users</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Shortlisted Candidates</div>
				<?php 
				if($page=="sort_cand"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="shortlisted_candidates.php">Shortlisted Candidates</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Create Admin</div>
				<?php 
				if($page=="createadmin"){?>
					<ul id="home"><?php
				}else{?>
				<ul id="box"><?php
				}?>
					<li class="b1"><a class="icon view_page" href="createadmin.php">Create Admin</a></li>								
						
				</ul>
			</div>
			<div class="box">
				<div class="h_title">&#8250; Logout</div>				
				<ul id="box">
					<li class="b1"><a class="icon view_page" href="logout.php">Logout</a></li>								
						
				</ul>
			</div>
		</div>