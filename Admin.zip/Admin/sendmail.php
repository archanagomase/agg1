<?php
$to = $_GET['email'];
$subject = "My subject";
$txt = "Some text";
$headers = "From: abangar91@appmonks.net" . "\r\n" .
"CC: ashwini@appmonks.net";

$sendmail=mail($to,$subject,$txt,$headers);
if($sendmail){
	header('location:applications.php');
}
?> 