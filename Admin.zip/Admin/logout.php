<?php
session_start();
include 'Includes/connections.php';
//$Username=$_SESSION['Username'];
session_destroy();
?>
<script>
alert('Logout successfully');
window.location.href = 'index.php';
</script>
