<?php
$Username="";
$Password="";
include 'Includes/connections.php';
if(isset($_POST['submit']))
{

$Username=$_POST['login'];
$Password2=$_POST['pass'];
$enc = base64_encode($Password2);
$dob=$_POST['dob'];
$query="insert into admin(id, date ,dob,username,password)values('',now(),'$dob','$Username','$enc')";

$success=mysqli_query($conn,$query);
if($success)
{
	echo "<script>alert('Admin created successfully'); window.location = 'createadmin.php';</script>";

}
}
?>
