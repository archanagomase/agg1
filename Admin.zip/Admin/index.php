<?php require ('loginaction.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" class="notranslate">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Paweł 'kilab' Balicki - kilab.pl" />
<title>Cms</title>
<link rel="stylesheet" type="text/css" href="css/login.css" media="screen" />
<script type="text/javascript" src="login.js"></script>
<style>
h1 {
    text-align: center;
}
.logo img{ 
          position:absolute;         
          padding: 0 0 0 125px;


}
</style>
</head>
<body>
<div class="wrap">
 <span class="logo">
           <img src="img/appreazlogo1.jpg" alt="">
       </span>


	<div id="content">
	<h1><b>Admin</b></h1>
		<div id="main">
		
			<div class="full_w">
				<form action="" method="post" onsubmit="return validateform()" name="loginform">
                <?php echo $error;?>
					<label for="login">EMP Code:</label>
					<input id="login" name="login" class="text"  autofocus="autofocus" />
					<label for="pass">Password:</label>
					<input id="pass" name="pass" type="password" class="text" />					
					<input id="roles" name="roles" type="hidden" class="text" value="<?php echo $_GET['roles'];?>"/>
					<div class="sep"></div>
					<button type="submit"  name="submit" >Login</button> 
				</form>
			</div>
			
		</div>
	</div>
</div>

</body>
</html>