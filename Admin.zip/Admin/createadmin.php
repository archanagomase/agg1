<?php
ob_start();
session_start();
 if($_SESSION['AdminUsername']==''){
	header('location:index.php');
}
else
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pl" xml:lang="pl">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Pawel 'kilab' Balicki - kilab.pl" />
<title>Customize CMS</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/navi.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>

	
		<script type="text/javascript" src="jquery-1.11.2.min.js"></script>


<script type="text/javascript">
$(function(){
	$(".box .h_title").not(this).next("ul").hide("normal");
	$(".box .h_title").not(this).next("#home").show("normal");
	$(".box").children(".h_title").click( function() { $(this).next("ul").slideToggle(); });
});
</script>
<style>
h1 {
    text-align: center;
}
h2 {
    text-align: right;
}

</style>
<!--Script by hscripts.com-->
<!-- Free javascripts @ https://www.hscripts.com -->

<!-- Script by hscripts.com -->
</head>
<body>

<div class="wrap" >
	<?php include 'Includes/header.php'?>
	
	<div id="content">
		<?php 
			$page="createadmin";
			include 'Includes/sidebar.php'?>
		<h1><b>Create Admin</b></h1>
		<div id="main">
		
			<div class="full_w">
				<form action="createadminaction.php" method="post"  name="loginform">
                <?php echo $error;?>
					<label for="login">EMP Code:</label>
					<input id="login" name="login" class="text"  autofocus="autofocus" required="required" />
					<label for="dob">DOB:</label>
					<input id="dob" name="dob" class="text" required="required" />
					<label for="pass">Password:</label>
					<input id="pass" name="pass" type="password" class="text" required="" />
					<div class="sep"></div>
					<input type="submit"  name="submit" value="Create Admin" style="background:#1e90ff;height:40px;" >
				</form>
			</div>
			
		</div>
		</div>
		<div class="clear"></div>
	</div>
<?php include 'Includes/footer.php'?>
	
</div>

</body>
</html>
<?php
}
?>