<?php
session_start();
$Username="";
$Password="";
$error="";
include 'Includes/connections.php';
if(isset($_POST['submit']))
{
$Username=$_POST['login'];
$Password2=$_POST['pass'];
$enc = base64_encode($Password2);

$query="select * from admin where username='$Username' and password='$enc'";

$success = mysqli_query($conn, $query);
if(mysqli_num_rows($success)>0)
{
$_SESSION['AdminUsername']=$Username;

$query="Update admin set date=now() where username='$Username'";
$success = mysqli_query($conn, $query);
header('location:details.php');
}
else
{
$error= "Emailid not exit";
}
}

?>