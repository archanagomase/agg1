<?php
ob_start();
session_start();
 if($_SESSION['AdminUsername']==''){
	header('location:index.php');
}
else
{
?>
<?php include 'Includes/connections.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pl" xml:lang="pl">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Pawel 'kilab' Balicki - kilab.pl" />
<title>Customize CMS</title>
<link href="http://appmonks.net/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/navi.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">

		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>

	
		<script type="text/javascript" src="jquery-1.11.2.min.js"></script>


<script type="text/javascript">
$(function(){
	$(".box .h_title").not(this).next("ul").hide("normal");
	$(".box .h_title").not(this).next("#home").show("normal");
	$(".box").children(".h_title").click( function() { $(this).next("ul").slideToggle(); });
});
</script>
<style>
	#nos {
			background: cyan;
		}
   #nos span {
			display: block;
			background: #1e90ff;
			color:white;
			max-width: 120px;
			margin:auto;
		}
     strong {
    
          font-size: 20px;
    
     }
 
</style>
<!--Script by hscripts.com-->
<!-- Free javascripts @ https://www.hscripts.com -->

<!-- Script by hscripts.com -->
</head>
<body>

<div class="wrap" >
	<?php include 'Includes/header.php'?>
	
	<div id="content">
		<?php 
			$page="details";
			include 'Includes/sidebar.php'?>		
		<div id="main">
		<div id="nos" class="col-md-8">
		<div class="row">
		<?php 
		$query="select * from job";
		$success=mysqli_query($conn,$query);		
		$job=mysqli_num_rows($success); 
		?>
			<div class="text-center col-md-6">
				<h2><span><?php if($job>0){ echo $job;}else{echo "0";}?></span></h2>
				<strong>No. of Jobs.</strong>
			</div>
			<?php 
		$query="select * from jobseeker";
		$success=mysqli_query($conn,$query);		
		$user=mysqli_num_rows($success); 
			?>

			<div class="text-center col-md-6">
				<h2><span><?php if($user>0){ echo $user;}else{echo "0";}?></span></h2>
				<strong>No. of Users.</strong>
			</div>
			
		</div>
		<div class="row">
			<div class="text-center col-md-6">
				<h2><span>5</span></h2>
				<strong>No. of Vaccancy.</strong>
			</div>
			<?php 		
		$query="select * from application";
		$success=mysqli_query($conn,$query);		
		$application=mysqli_num_rows($success); 
			?>
			<div class="text-center col-md-6">
				<h2><span><?php if($application>0){ echo $application;}else{echo "0";}?></span></h2>
				<strong>No. of Applicants.</strong>
			</div>
			
		</div>
		<div class="row">
		<?php 		
		$query="select * from shortlisted";
		$success=mysqli_query($conn,$query);		
		$shortlisted=mysqli_num_rows($success); 
			?>
			<div class="text-center col-md-6">
				<h2><span><?php if($shortlisted>0){ echo $shortlisted;}else{echo "0";}?></span></h2>
				<strong>No. of Shortlisted Candidates.</strong>
			</div>
			<?php 		
		$query="select * from recruiter";
		$success=mysqli_query($conn,$query);		
		$recruiter=mysqli_num_rows($success); 
			?>
			<div class="text-center col-md-6">
				<h2><span><?php if($recruiter>0){ echo $recruiter;}else{echo "0";}?></span></h2>
				<strong>No. of Recruiters.</strong>
			</div>
		</div>
	</div>
			
		</div>
		
		<div class="clear"></div>
		
	</div>
<?php include 'Includes/footer.php'?>
	
</div>

</body>
</html>

<?php }
?>
