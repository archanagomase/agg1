<?php
ob_start();
session_start();
 if($_SESSION['AdminUsername']==''){
	header('location:index.php');
}
else
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pl" xml:lang="pl">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Pawel 'kilab' Balicki - kilab.pl" />
<title>Customize CMS</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/navi.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
		<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#employee-grid').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						url :"usersgrid.php", // json datasource
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".employee-grid-error").html("");
							$("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
							$("#employee-grid_processing").css("display","none");
							
						}
					}
				} );
			} );
		</script>
		<script type="text/javascript" src="jquery-1.11.2.min.js"></script>


<script type="text/javascript">
$(function(){
	$(".box .h_title").not(this).next("ul").hide("normal");
	$(".box .h_title").not(this).next("#home").show("normal");
	$(".box").children(".h_title").click( function() { $(this).next("ul").slideToggle(); });
});
</script>
<style>
h1 {
    text-align: center;
}
h2 {
    text-align: right;
}
div.image {
     left: 1080px;
    position: absolute;
    top: 58px;
}
@media only screen and (max-width: 767px )
{
div.image  {
left: 704px;
position: absolute;
top: 58px;
}
}
</style>
<!--Script by hscripts.com-->
<!-- Free javascripts @ https://www.hscripts.com -->

<!-- Script by hscripts.com -->
</head>
<body>

<div class="wrap" >
	<?php include 'Includes/header.php'?>
	
	<div id="content">
		<?php 
			$page="users";
			include 'Includes/sidebar.php'?>
		<div id="main">
        <?php echo '<h1>Users</h1>';?>
        <div class="image"><a href="userscsv.php"><img src="img/index.jpg" align="right"></a></div>
        <h2>Download CSV</h2>
				<div class="container">
                  

			<table id="employee-grid"  cellpadding="0" cellspacing="0" border="0" class="display" width="100%">
					<thead>
						<tr>
							<th>Name</th>
							<th>Phone</th>	
                            <th>Email</th>                    													
							<th>DOB</th>
							<th>Current Location</th>
							<th>Preferred Locations</th>
							<th>Gender</th>
							<th>Notice Period</th>
							<th>Experience</th>
							<th>Current Salary</th>																		<th>Expected Salary</th>
							<th>Created At</th>                            
						</tr>
					</thead>
			</table>
            
		</div>
		</div>
		<div class="clear"></div>
	</div>
<?php include 'Includes/footer.php'?>
	
</div>

</body>
</html>
<?php
}
?>