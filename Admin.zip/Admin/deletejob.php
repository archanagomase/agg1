<?php
include 'Includes/connections.php';
$id=$_GET['id'];
$query="delete from job where id=$id";
$success=mysqli_query($conn,$query);
if($success)
{
header('location:jobs.php');
}
?>
