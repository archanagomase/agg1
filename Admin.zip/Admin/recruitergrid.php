
<?php
include 'Includes/connections.php';
/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 =>'name', 
	1 => 'phone',	
	2=> 'email',
	3=>'password',
	4=> 'designation',
	5=> 'location',
	6=> 'about',
	7=>'facebook',
	8=>'linkedin',
	9=>'twitter',
	10=>'google',
	11=> 'created_on',
	12=>'avatar',
	13=>'notification',
	14=>'id'
);

// getting total number records without any search
$sql = "SELECT id ,name,phone,email,password,designation,location,about,facebook,linkedin,twitter,google,created_on,avatar,notification";
$sql.=" FROM recruiter";

$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT id ,name,phone,email,password,designation,location,about,facebook,linkedin,twitter,google,created_on,avatar,notification";
$sql.=" FROM recruiter WHERE 1=1 ";

if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND ( name LIKE '".$requestData['search']['value']."%' ";
    $sql.=" OR id LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR phone LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR designation LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR location LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR about LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR created_on LIKE '".$requestData['search']['value']."%' ";
    $sql.=" OR password LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR facebook LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR linkedin LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR twitter LIKE '".$requestData['search']['value']."%' ";			
    $sql.=" OR google LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR avatar LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR email LIKE '".$requestData['search']['value']."%' )";
	
	
}
$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY id desc LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");

$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array

	
	$nestedData=array(); 
	$nestedData[] = $row["name"];
	$nestedData[] = $row["phone"];
    $nestedData[] = $row["email"];   	
    $nestedData[] = $row["designation"];	
    $nestedData[] = $row["location"];	
    $nestedData[] = $row["about"];	
    $nestedData[] = $row["facebook"];
    $nestedData[] = $row["linkedin"];
    $nestedData[] = $row["twitter"];
    $nestedData[] = $row["google"];
    $nestedData[] = $row["created_on"];	    
	$data[] = $nestedData;
}


$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
