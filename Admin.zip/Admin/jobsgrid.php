
<?php
include 'Includes/connections.php';
/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 =>'recruiter_id', 
	1 => 'posted_on',	
	2=> 'title',
	3=>'min_salary',
	4=> 'max_salary',
	5=> 'min_experience',
	6=> 'max_experience',
	7=>'course_type',
	8=>'qualification',
	9=>'keywords',	
	10=>'id'
);

// getting total number records without any search
$sql = "SELECT id ,recruiter_id,posted_on,title,min_salary,max_salary,min_experience,max_experience,course_type,qualification,keywords";
$sql.=" FROM job";

$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT id ,recruiter_id,posted_on,title,min_salary,max_salary,min_experience,max_experience,course_type,qualification,keywords";
$sql.=" FROM job WHERE 1=1 ";

if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND ( name LIKE '".$requestData['search']['value']."%' ";
    $sql.=" OR id LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR recruiter_id LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR posted_on LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR title LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR min_salary LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR max_salary LIKE '".$requestData['search']['value']."%' ";
    $sql.=" OR min_experience LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR max_experience LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR course_type LIKE '".$requestData['search']['value']."%' ";	
    $sql.=" OR qualification LIKE '".$requestData['search']['value']."%' ";	   
    $sql.=" OR keywords LIKE '".$requestData['search']['value']."%' )";
	
	
}
$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY id desc LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($conn, $sql) or die("employee-grid-data.php: get employees");

$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array

	
	$nestedData=array(); 
	$nestedData[] = $row["recruiter_id"];
	$nestedData[] = $row["posted_on"];
    $nestedData[] = $row["title"];   	
    $nestedData[] = $row["min_salary"];	
    $nestedData[] = $row["max_salary"];	
    $nestedData[] = $row["min_experience"];	
    $nestedData[] = $row["max_experience"];
    $nestedData[] = $row["course_type"];
    $nestedData[] = $row["qualification"];
    $nestedData[] = $row["keywords"]; 
    $nestedData[] = '<a href="deletejob.php?id='.$row['id'].'" class="table-icon delete" title="Delete"  Onclick="return delete_confirm()" ></a>';      
	$data[] = $nestedData;
}


$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
