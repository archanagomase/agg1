<?php
include 'Includes/connections.php';
$id=$_GET['id'];
$query="delete from projects where id=$id";
$success=mysqli_query($conn,$query);
if($success)
{
header('location:Allprojects.php');
}
?>
